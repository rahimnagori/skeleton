<?php

if ( ! function_exists( 'pelicula_child_theme_enqueue_scripts' ) ) {
	/**
	 * Function that enqueue theme's child style
	 */
	function pelicula_child_theme_enqueue_scripts() {
		$main_style = 'pelicula-main';
		
		wp_enqueue_style( 'pelicula-child-style', get_stylesheet_directory_uri() . '/style.css', array( $main_style ) );
	}
	
	add_action( 'wp_enqueue_scripts', 'pelicula_child_theme_enqueue_scripts' );
}


function add_google_fonts() {

wp_enqueue_style( 'add_google_fonts', 'https://fonts.googleapis.com/css?family=Fraunces:wght@800&display=swap', false );}

add_action( 'wp_enqueue_scripts', 'add_google_fonts' );